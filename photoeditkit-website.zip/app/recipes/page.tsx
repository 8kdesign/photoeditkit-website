import type { Metadata } from "next";
import { RecipeBrowser } from "@/components/RecipeBrowser";
import { Eyebrow } from "@/components/ui";
import { links } from "@/lib/content";

export const metadata: Metadata = {
  title: "Recipes",
  description:
    "Every PhotoEditKit suggestion comes from a fixed set of corrections, styles and themes, calibrated to each photo.",
};

export default function RecipesPage() {
  return (
    <main
      className="container"
      style={{ paddingTop: 80, paddingBottom: 96, display: "flex", flexDirection: "column", gap: 40 }}
    >
      <RecipeBrowser
        intro={
          <>
            <Eyebrow>The recipes</Eyebrow>
            <h1
              style={{
                margin: 0,
                fontSize: "clamp(40px, 4.4vw, 56px)",
                lineHeight: 1.07,
                fontWeight: 600,
                letterSpacing: "-0.03em",
              }}
            >
              Every suggestion comes from one of these.
            </h1>
            <p style={{ margin: 0, fontSize: 18, lineHeight: "28px", color: "var(--ink-muted)", maxWidth: 640 }}>
              The AI picks only the recipes a photo needs, calibrates each one to it, and ranks the most useful first.
              Corrections come before styles; themes appear only when you ask for them.
            </p>
          </>
        }
      />
      <div
        style={{
          background: "var(--surface-1)",
          borderRadius: "var(--radius-lg)",
          boxShadow: "var(--shadow-card)",
          padding: 24,
          display: "flex",
          flexWrap: "wrap",
          gap: "16px 40px",
          alignItems: "center",
        }}
      >
        <h2 style={{ margin: 0, fontSize: 20, lineHeight: "28px", fontWeight: 600 }}>On every recipe</h2>
        <p style={{ margin: 0, fontSize: 14, lineHeight: "22px", color: "var(--ink-muted)", flex: "1 1 420px" }}>
          Skin keeps a natural hue and saturation, grain and clipping guardrails stay on, and every value is an
          inspectable slider: no hidden adjustments your UI can’t show or change.
        </p>
        <a href={links.recipesApi} style={{ fontSize: 14, fontWeight: 500 }}>
          Read the API →
        </a>
      </div>
    </main>
  );
}
