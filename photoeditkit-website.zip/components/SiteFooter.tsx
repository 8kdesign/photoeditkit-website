import Link from "next/link";
import { links } from "@/lib/content";
import { Wordmark } from "./SunMark";

export function SiteFooter() {
  const linkStyle = { color: "var(--ink-muted)", fontSize: 14 } as const;
  return (
    <footer style={{ borderTop: "1px solid var(--line)" }}>
      <div
        className="container"
        style={{
          paddingBlock: 40,
          display: "flex",
          flexWrap: "wrap",
          gap: 24,
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Wordmark size={22} />
        <nav aria-label="Footer" style={{ display: "flex", flexWrap: "wrap", gap: "8px 24px" }}>
          <a href={links.iosRepo} style={linkStyle}>iOS &amp; macOS on GitHub</a>
          <a href={links.androidRepo} style={linkStyle}>Android on GitHub</a>
          <Link href="/recipes" style={linkStyle}>Recipes</Link>
          <Link href="/#privacy" style={linkStyle}>Privacy</Link>
        </nav>
      </div>
    </footer>
  );
}
