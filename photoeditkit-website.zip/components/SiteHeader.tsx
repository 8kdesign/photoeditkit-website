"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { links } from "@/lib/content";
import { Wordmark } from "./SunMark";
import { ButtonLink, GitHubIcon } from "./ui";
import styles from "./SiteHeader.module.css";

const nav = [
  { label: "Overview", href: "/" },
  { label: "Recipes", href: "/recipes" },
  { label: "Privacy", href: "/#privacy" },
];

export function SiteHeader() {
  const pathname = usePathname();
  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.brand} aria-label="PhotoEditKit home">
          <Wordmark />
        </Link>
        <nav aria-label="Main" className={styles.nav}>
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={pathname === item.href ? "page" : undefined}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className={styles.end}>
          <a
            href={links.iosRepo}
            className={styles.iconButton}
            aria-label="PhotoEditKit on GitHub"
            target="_blank"
            rel="noopener noreferrer"
          >
            <GitHubIcon size={18} />
          </a>
          <ButtonLink href={links.iosQuickStart} external>
            Get started
          </ButtonLink>
        </div>
      </div>
    </header>
  );
}
